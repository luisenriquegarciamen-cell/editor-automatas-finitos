-- Script compartido: ejecútenlo los 3 antes de empezar a programar.

CREATE DATABASE IF NOT EXISTS biblioteca_universitaria
CHARACTER SET utf8mb4;

USE biblioteca_universitaria;

-- Tabla del Integrante 1
CREATE TABLE IF NOT EXISTS libro (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(150) NOT NULL,
    autor VARCHAR(100) NOT NULL,
    categoria VARCHAR(60) NOT NULL,
    stock INT NOT NULL
);

-- Tabla del Integrante 2
CREATE TABLE IF NOT EXISTS usuario (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    correo VARCHAR(100) NOT NULL,
    carrera VARCHAR(100) NOT NULL
);

-- Tabla del Integrante 3 (relaciona las dos anteriores)
CREATE TABLE IF NOT EXISTS prestamo (
    id INT AUTO_INCREMENT PRIMARY KEY,
    libro_id INT NOT NULL,
    usuario_id INT NOT NULL,
    fecha_prestamo DATE NOT NULL,
    fecha_devolucion DATE NULL,
    estado VARCHAR(20) NOT NULL,
    FOREIGN KEY (libro_id) REFERENCES libro(id),
    FOREIGN KEY (usuario_id) REFERENCES usuario(id)
);

-- Datos de prueba opcionales
INSERT INTO libro (titulo, autor, categoria, stock) VALUES
('Cien años de soledad', 'Gabriel García Márquez', 'Novela', 3),
('Clean Code', 'Robert C. Martin', 'Tecnología', 2);

INSERT INTO usuario (nombre, correo, carrera) VALUES
('Ana Torres', 'ana@correo.com', 'Ingeniería de Sistemas'),
('Luis Pérez', 'luis@correo.com', 'Ingeniería Industrial');
